/*
* Licensee agrees that the example code provided to Licensee has been developed and released by Bosch solely as an example to be used as a potential reference for Licensee�s application development. 
* Fitness and suitability of the example code for any use within Licensee�s applications need to be verified by Licensee on its own authority by taking appropriate state of the art actions and measures (e.g. by means of quality assurance measures).
* Licensee shall be responsible for conducting the development of its applications as well as integration of parts of the example code into such applications, taking into account the state of the art of technology and any statutory regulations and provisions applicable for such applications. Compliance with the functional system requirements and testing there of (including validation of information/data security aspects and functional safety) and release shall be solely incumbent upon Licensee. 
* For the avoidance of doubt, Licensee shall be responsible and fully liable for the applications and any distribution of such applications into the market.
* 
* 
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are 
* met:
* 
*     (1) Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer. 
* 
*     (2) Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.  
*     
*     (3)The name of the author may not be used to
*     endorse or promote products derived from this software without
*     specific prior written permission.
* 
*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
*  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
*  DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
*  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
*  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
*  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
*  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
*  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
*  IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
*  POSSIBILITY OF SUCH DAMAGE.
*/
/*----------------------------------------------------------------------------*/
/**
 *  @file        
 *
 * Demo application of printing BMI160 Accel and Gyro data on serialport(USB virtual comport)
 * every one second, initiated by auto-reloaded timer(freeRTOS)
 * 
 * ****************************************************************************/

/* module includes ********************************************************** */

/* own header files */
#include "XdkSensorHandle.h"
#include "XDK_Datalogger_ih.h"
#include "XDK_Datalogger_ch.h"
#include "BMI_160_ih.h"
#include "BMI_160_ch.h"

/* system header files */
#include <stdio.h>
#include <BCDS_Basics.h>

/* additional interface header files */
#include "BCDS_BSP_LED.h"
#include "BSP_BoardType.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "BCDS_Accelerometer.h"
#include "BCDS_Gyroscope.h"
#include "BCDS_Retcode.h"

/* constant definitions ***************************************************** */

/* local variables ********************************************************** */
/* global variables ********************************************************* */
Accelerometer_XyzData_T getAccelDataRaw160 = { INT32_C(0), INT32_C(0), INT32_C(0) };
Accelerometer_XyzData_T getAccelDataUnit160 = { INT32_C(0), INT32_C(0), INT32_C(0) };
Gyroscope_XyzData_T getGyroDataRaw160 = { INT32_C(0), INT32_C(0), INT32_C(0) };
Gyroscope_XyzData_T getGyroDataConv160 = { INT32_C(0), INT32_C(0), INT32_C(0) };
Gyroscope_Bandwidth_T bmi160gyro_bw = GYROSCOPE_BANDWIDTH_OUT_OF_RANGE;
Accelerometer_Bandwidth_T bmi160accel_bw = ACCELEROMETER_BANDWIDTH_OUT_OF_RANGE;
Accelerometer_Range_T bmi160range = ACCELEROMETER_RANGE_OUT_OF_BOUND;
/* inline functions ********************************************************* */

/* local functions ********************************************************** */
/** The function to get and print the accel data using printf
 * @brief Gets the data from BMI160 Accel and BMI160 Gyro
 *
 * @param[in] pvParameters Rtos task should be defined with the type void *(as argument)
 */
void bmi160_getSensorValues(void *pvParameters)
{

    /* Return value for Accel Sensor */
    Retcode_T accelReturnValue = (Retcode_T) RETCODE_FAILURE;
    Retcode_T gyroReturnValue = (Retcode_T) RETCODE_FAILURE;
    (void) pvParameters;

    accelReturnValue = Accelerometer_readXyzLsbValue(xdkAccelerometers_BMI160_Handle, &getAccelDataRaw160);
    if (RETCODE_OK != accelReturnValue)
    {
          printf("BMI160 Read Raw Data Failed\r\n");
    }
    accelReturnValue = Accelerometer_readXyzGValue(xdkAccelerometers_BMI160_Handle, &getAccelDataUnit160);
    if (RETCODE_OK != accelReturnValue)
    {
         printf("BMI160 Read G Data Failed\r\n");
    }
    gyroReturnValue = Gyroscope_readXyzValue(xdkGyroscope_BMI160_Handle, &getGyroDataRaw160);
    if (RETCODE_OK != gyroReturnValue)
    {
          printf("BMI160 GyrosensorReadRawData Failed\r\n");
    }
    /* read sensor data in milli Degree*/
    gyroReturnValue = Gyroscope_readXyzDegreeValue(xdkGyroscope_BMI160_Handle, &getGyroDataConv160);
    if (RETCODE_OK != gyroReturnValue)
    {
          printf("BMI160 GyrosensorReadInMilliDeg Failed\r\n");
    }
}
/* global functions ********************************************************* */
/**
 * @brief The function initializes BMI(Interial-accel & gyro) and set sensor parameter from logger.ini
 *
 */
extern void bmi_160_init(void)
{
    /* Return value for Accel Sensor */
    Retcode_T accelReturnValue = (Retcode_T) RETCODE_FAILURE;
    /* Return value for Accel Sensor */
    Retcode_T gyroReturnValue = (Retcode_T) RETCODE_FAILURE;
    /*initialize accel*/
    Retcode_T returnVal = RETCODE_OK;
    accelReturnValue = Accelerometer_init(xdkAccelerometers_BMI160_Handle);
    gyroReturnValue = Gyroscope_init(xdkGyroscope_BMI160_Handle);
    if ((RETCODE_OK == accelReturnValue)
            && (RETCODE_OK == gyroReturnValue))
    {
        printf("BMI160 Init Succeed\r\n");
    }
    else
    {
        returnVal = BSP_LED_Switch(BSP_XDK_LED_R, BSP_LED_COMMAND_ON);
        if (RETCODE_OK != returnVal)
        {
            printf("Turning on of RED LED failed");
        }
        printf("BMI160 Init failed\r\n");
    }

    if (config.bmi160_range == 2)
    {
        bmi160range = ACCELEROMETER_BMA280_RANGE_2G;
    }
    else if (config.bmi160_range == 4)
    {
        bmi160range = ACCELEROMETER_BMA280_RANGE_4G;
    }
    else if (config.bmi160_range == 8)
    {
        bmi160range = ACCELEROMETER_BMA280_RANGE_8G;
    }
    else if (config.bmi160_range == 16)
    {
        bmi160range = ACCELEROMETER_BMA280_RANGE_16G;
    }
    accelReturnValue = Accelerometer_setRange(xdkAccelerometers_BMI160_Handle,
            bmi160range);
    if ((RETCODE_OK != accelReturnValue)
            || (ACCELEROMETER_RANGE_OUT_OF_BOUND == bmi160range))
    {
        returnVal = BSP_LED_Switch(BSP_XDK_LED_R, BSP_LED_COMMAND_ON);
        if (RETCODE_OK != returnVal)
        {
            printf("Turning on of RED LED failed");
        }
    }

    if (strcmp(bmi160_accel_bw, "7.81") == 0)
    {
        bmi160accel_bw = ACCELEROMETER_BMA280_BANDWIDTH_7_81HZ;
    }
    else if (strcmp(bmi160_accel_bw, "15.63") == 0)
    {
        bmi160accel_bw = ACCELEROMETER_BMA280_BANDWIDTH_15_63HZ;
    }
    else if (strcmp(bmi160_accel_bw, "31.25") == 0)
    {
        bmi160accel_bw = ACCELEROMETER_BMA280_BANDWIDTH_31_25HZ;
    }
    else if (strcmp(bmi160_accel_bw, "62.5") == 0)
    {
        bmi160accel_bw = ACCELEROMETER_BMA280_BANDWIDTH_62_50HZ;
    }
    if (strcmp(bmi160_accel_bw, "125") == 0)
    {
        bmi160accel_bw = ACCELEROMETER_BMA280_BANDWIDTH_125HZ;
    }
    if (strcmp(bmi160_accel_bw, "250") == 0)
    {
        bmi160accel_bw = ACCELEROMETER_BMA280_BANDWIDTH_250HZ;
    }
    if (strcmp(bmi160_accel_bw, "500") == 0)
    {
        bmi160accel_bw = ACCELEROMETER_BMA280_BANDWIDTH_500HZ;
    }
    accelReturnValue = Accelerometer_setBandwidth(
            xdkAccelerometers_BMI160_Handle, bmi160accel_bw);

    if ((RETCODE_OK != accelReturnValue)
            || (ACCELEROMETER_BANDWIDTH_OUT_OF_RANGE == bmi160accel_bw))
    {
        returnVal = BSP_LED_Switch(BSP_XDK_LED_R, BSP_LED_COMMAND_ON);
        if (RETCODE_OK != returnVal)
        {
            printf("Turning on of RED LED failed");
        }
    }

    /*Set gyroscpe value */
    if (strcmp(bmi160_gyro_bw, "32") == 0)
    {
        bmi160gyro_bw = GYROSCOPE_BMG160_BANDWIDTH_32HZ;
    }
    else if (strcmp(bmi160_gyro_bw, "64") == 0)
    {
        bmi160gyro_bw = GYROSCOPE_BMG160_BANDWIDTH_64HZ;
    }
    else if (strcmp(bmi160_gyro_bw, "12") == 0)
    {
        bmi160gyro_bw = GYROSCOPE_BMG160_BANDWIDTH_12HZ;
    }
    else if (strcmp(bmi160_gyro_bw, "23") == 0)
    {
        bmi160gyro_bw = GYROSCOPE_BMG160_BANDWIDTH_23HZ;
    }
    else if (strcmp(bmi160_gyro_bw, "47") == 0)
    {
        bmi160gyro_bw = GYROSCOPE_BMG160_BANDWIDTH_47HZ;
    }
    else if (strcmp(bmi160_gyro_bw, "116") == 0)
    {
        bmi160gyro_bw = GYROSCOPE_BMG160_BANDWIDTH_116HZ;
    }
    else if (strcmp(bmi160_gyro_bw, "230") == 0)
    {
        bmi160gyro_bw = GYROSCOPE_BMG160_BANDWIDTH_230HZ;
    }
    gyroReturnValue = Gyroscope_setBandwidth(xdkGyroscope_BMI160_Handle, bmi160gyro_bw);
    if ((RETCODE_OK != gyroReturnValue)
            || (GYROSCOPE_BANDWIDTH_OUT_OF_RANGE == bmi160gyro_bw))
    {
        returnVal = BSP_LED_Switch(BSP_XDK_LED_R, BSP_LED_COMMAND_ON);
        if (RETCODE_OK != returnVal)
        {
            printf("Turning on of RED LED failed");
        }
    }

}

/**
 *  @brief API to Deinitialize the PID module
 */
extern void bmi160_deInit(void)
{
    /* Return value for Accel Sensor */
    Retcode_T accelReturnValue = RETCODE_FAILURE;

    /* Return value for Accel Sensor */
    Retcode_T gyroReturnValue = RETCODE_FAILURE;

    /*initialize accel*/
    accelReturnValue = Accelerometer_deInit(xdkAccelerometers_BMI160_Handle);
    /*initialize gyro*/
    gyroReturnValue = Gyroscope_deInit(xdkGyroscope_BMI160_Handle);

    if ((RETCODE_OK == accelReturnValue) && (RETCODE_OK == gyroReturnValue))
    {
        printf("InertialSensor Deinit Success\r\n");
    }
    else
    {
        printf("InertialSensor Deinit Failed\r\n");
    }
}

/** ************************************************************************* */
