/*
* Licensee agrees that the example code provided to Licensee has been developed and released by Bosch solely as an example to be used as a potential reference for Licensee�s application development. 
* Fitness and suitability of the example code for any use within Licensee�s applications need to be verified by Licensee on its own authority by taking appropriate state of the art actions and measures (e.g. by means of quality assurance measures).
* Licensee shall be responsible for conducting the development of its applications as well as integration of parts of the example code into such applications, taking into account the state of the art of technology and any statutory regulations and provisions applicable for such applications. Compliance with the functional system requirements and testing there of (including validation of information/data security aspects and functional safety) and release shall be solely incumbent upon Licensee. 
* For the avoidance of doubt, Licensee shall be responsible and fully liable for the applications and any distribution of such applications into the market.
* 
* 
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are 
* met:
* 
*     (1) Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer. 
* 
*     (2) Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.  
*     
*     (3)The name of the author may not be used to
*     endorse or promote products derived from this software without
*     specific prior written permission.
* 
*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
*  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
*  DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
*  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
*  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
*  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
*  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
*  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
*  IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
*  POSSIBILITY OF SUCH DAMAGE.
*/
/*----------------------------------------------------------------------------*/
/**
 *  @file        
 *
 * @brief
 *   This Application is to demonstrate Gyrosensor Advanced APIs.
 * ****************************************************************************/

/* module includes ********************************************************** */

/* own header files */
#include "XdkSensorHandle.h"
#include "XDK_Datalogger_ch.h"
#include "XDK_Datalogger_ih.h"
#include "BMG_160_ch.h"
#include "BMG_160_ih.h"

/* system header files */
#include <stdio.h>
#include <BCDS_Basics.h>

/* additional interface header files */
#include "BCDS_BSP_LED.h"
#include "BSP_BoardType.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "BCDS_Gyroscope.h"
#include "BCDS_Retcode.h"

/* local prototypes ********************************************************* */

/* constant definitions ***************************************************** */

/* local variables ********************************************************** */

/* global variables ********************************************************* */
/* variable to store timer handle*/
xTimerHandle PGD_printTimerHandle_gdt;
Gyroscope_XyzData_T getRawData = { INT32_C(0), INT32_C(0), INT32_C(0) };
Gyroscope_XyzData_T getMdegData = { INT32_C(0), INT32_C(0), INT32_C(0) };
Gyroscope_Bandwidth_T bmg160bw = GYROSCOPE_BANDWIDTH_OUT_OF_RANGE;

/* inline functions ********************************************************* */

/* local functions ********************************************************** */

/* global functions ********************************************************* */
/**
 * @brief The function initializes BMG160 sensor and set the sensor parameter from logger.ini
 */
void bmg_160_init(void)
{
    Retcode_T returnValue = (Retcode_T) RETCODE_FAILURE;
    Retcode_T returnVal = RETCODE_OK;
    /*initialize Gyro sensor*/
    returnValue = Gyroscope_init(xdkGyroscope_BMG160_Handle);

    if (RETCODE_OK == returnValue)
    {
        printf("GyroInit Success\r\n");
    }
    else
    {
        returnVal = BSP_LED_Switch(BSP_XDK_LED_R, BSP_LED_COMMAND_ON);
        if (RETCODE_OK != returnVal)
        {
            printf("Turning on of RED LED failed");

        }

        printf("GyroInit Failed\r\n");
    }
    if (strcmp(bmg160_bw, "32") == 0)
    {
        bmg160bw = GYROSCOPE_BMG160_BANDWIDTH_32HZ;
    }
    else if (strcmp(bmg160_bw, "64") == 0)
    {
        bmg160bw = GYROSCOPE_BMG160_BANDWIDTH_64HZ;
    }
    else if (strcmp(bmg160_bw, "12") == 0)
    {
        bmg160bw = GYROSCOPE_BMG160_BANDWIDTH_12HZ;
    }
    else if (strcmp(bmg160_bw, "23") == 0)
    {
        bmg160bw = GYROSCOPE_BMG160_BANDWIDTH_23HZ;
    }
    else if (strcmp(bmg160_bw, "47") == 0)
    {
        bmg160bw = GYROSCOPE_BMG160_BANDWIDTH_47HZ;
    }
    else if (strcmp(bmg160_bw, "116") == 0)
    {
        bmg160bw = GYROSCOPE_BMG160_BANDWIDTH_116HZ;
    }
    else if (strcmp(bmg160_bw, "230") == 0)
    {
        bmg160bw = GYROSCOPE_BMG160_BANDWIDTH_230HZ;
    }
    returnValue = Gyroscope_setBandwidth(xdkGyroscope_BMG160_Handle, bmg160bw);
    if ((RETCODE_OK != returnValue)
            || (GYROSCOPE_BANDWIDTH_OUT_OF_RANGE == bmg160bw))
    {
        returnVal = BSP_LED_Switch(BSP_XDK_LED_R, BSP_LED_COMMAND_ON);
        if (RETCODE_OK != returnVal)
        {
            printf("Turning on of RED LED failed");

        }
    }
}

/**
 * @brief Read data from Gyro sensor
 *
 * @param[in] pxTimer timer handle
 */
void bmg160_getSensorValues(xTimerHandle pxTimer)
{

    Retcode_T returnValue = (Retcode_T) RETCODE_FAILURE;
    (void) pxTimer; /* suppressing warning message */

    /* read Raw sensor data */
    returnValue = Gyroscope_readXyzValue(xdkGyroscope_BMG160_Handle, &getRawData);
    if (RETCODE_OK != returnValue)
    {
        printf("GyrosensorReadRaw Failed\r\n");
    }
    returnValue = Gyroscope_readXyzDegreeValue(xdkGyroscope_BMG160_Handle, &getMdegData);
    if (RETCODE_OK != returnValue)
    {
        printf("GyrosensorReadInMilliDeg Failed\r\n");
    }
}

/**
 *  @brief  The function to de-initialize
 *
 */
void bmg_160_deInit(void)
{
    Retcode_T returnValue = RETCODE_FAILURE;
    returnValue = Gyroscope_deInit(xdkGyroscope_BMG160_Handle);
    if (RETCODE_OK == returnValue)
    {
        printf("gyroscopeSensor Deinit Success\r\n");
    }
    else
    {
        printf("gyroscopeSensor Deinit Failed\r\n");
    }
}

/** ************************************************************************* */
