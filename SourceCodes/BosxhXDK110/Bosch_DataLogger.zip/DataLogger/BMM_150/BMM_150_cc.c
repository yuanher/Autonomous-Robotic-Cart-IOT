/*
* Licensee agrees that the example code provided to Licensee has been developed and released by Bosch solely as an example to be used as a potential reference for Licensee�s application development. 
* Fitness and suitability of the example code for any use within Licensee�s applications need to be verified by Licensee on its own authority by taking appropriate state of the art actions and measures (e.g. by means of quality assurance measures).
* Licensee shall be responsible for conducting the development of its applications as well as integration of parts of the example code into such applications, taking into account the state of the art of technology and any statutory regulations and provisions applicable for such applications. Compliance with the functional system requirements and testing there of (including validation of information/data security aspects and functional safety) and release shall be solely incumbent upon Licensee. 
* For the avoidance of doubt, Licensee shall be responsible and fully liable for the applications and any distribution of such applications into the market.
* 
* 
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are 
* met:
* 
*     (1) Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer. 
* 
*     (2) Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.  
*     
*     (3)The name of the author may not be used to
*     endorse or promote products derived from this software without
*     specific prior written permission.
* 
*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
*  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
*  DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
*  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
*  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
*  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
*  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
*  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
*  IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
*  POSSIBILITY OF SUCH DAMAGE.
*/
/*----------------------------------------------------------------------------*/
/**
 *  @file
 *
 * Demo application of printing BMM150 Magnetometer data on serialport(USB virtual comport)
 * every one second, initiated by autoreloaded timer(freertos)
 * 
 * ****************************************************************************/


/* module includes ********************************************************** */

/* own header files */
#include "XdkSensorHandle.h"
#include "XDK_Datalogger_ih.h"
#include "XDK_Datalogger_ch.h"
#include "BMM_150_ih.h"
#include "BMM_150_ch.h"

/* system header files */
#include <stdio.h>
#include <BCDS_Basics.h>

/* additional interface header files */
#include "BCDS_BSP_LED.h"
#include "BSP_BoardType.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "BCDS_Magnetometer.h"
#include "BCDS_Retcode.h"

/* constant definitions ***************************************************** */

/* local variables ********************************************************** */

/* global variables ********************************************************* */
Magnetometer_XyzData_T getMagDataRaw = { INT32_C(0), INT32_C(0), INT32_C(0), UINT32_C(0) };
Magnetometer_XyzData_T getMagDataUnit = { INT32_C(0), INT32_C(0), INT32_C(0), UINT32_C(0) };
Magnetometer_DataRate_T bmm150dr = MAGNETOMETER_DATARATE_OUT_OF_RANGE;
/* inline functions ********************************************************* */

/* local functions ********************************************************** */

/**@brief The function to gets the data BMM150 Magnetometer
 * @param[in] pvParameters Rtos task should be defined with the type void *(as argument)
 */

void bmm150_getSensorValues(xTimerHandle pxTimer)
{

    /* Return value for Magnetometer Sensor */
    Retcode_T sensorApiRetValue = (Retcode_T) RETCODE_FAILURE;
    (void) pxTimer;

    sensorApiRetValue = Magnetometer_readXyzLsbData(xdkMagnetometer_BMM150_Handle, &getMagDataRaw);
    if (RETCODE_OK == sensorApiRetValue)
    {
        ;
    }
    else
    {
        printf("Magnetometer XYZ lsb Data read FAILED\r\n");
    }

    sensorApiRetValue = Magnetometer_readXyzTeslaData(xdkMagnetometer_BMM150_Handle, &getMagDataUnit);
    if (RETCODE_OK == sensorApiRetValue)
    {
        ;
    }
    else
    {
        printf("Magnetometer XYZ MicroTeslaData read FAILED\r\n");
    }
}

/* global functions ********************************************************* */

/**
 * @brief The function initializes BMM150(magnetometer) and set the sensor parameter from logger.ini
 */
extern void bmm_150_init(void)
{
    Retcode_T returnVal = RETCODE_OK;

    /* Return value for magnetometerInit and magnetometerSetMode api*/
    Retcode_T magReturnValue = (Retcode_T) RETCODE_FAILURE;
    /* Initialization for Magnetometer Sensor */
    magReturnValue = Magnetometer_init(xdkMagnetometer_BMM150_Handle);
    if (RETCODE_OK == magReturnValue)
    {
        printf("BMM150 initialization Success\r\n");

    }
    else
    {
        returnVal = BSP_LED_Switch(BSP_XDK_LED_R, BSP_LED_COMMAND_ON);
             if (RETCODE_OK != returnVal)
             {
                 printf("Turning on of RED LED failed");
             }
        printf("Magnetometer initialization FAILED \r\n");
    }
    if (strcmp(bmm150_data, "10"))
    {
        bmm150dr = MAGNETOMETER_BMM150_DATARATE_10HZ;
    }
    else if (strcmp(bmm150_data, "2"))
    {
        bmm150dr = MAGNETOMETER_BMM150_DATARATE_2HZ;
    }
    else if (strcmp(bmm150_data, "6"))
    {
        bmm150dr = MAGNETOMETER_BMM150_DATARATE_6HZ;
    }
    else if (strcmp(bmm150_data, "15"))
    {
        bmm150dr = MAGNETOMETER_BMM150_DATARATE_15HZ;
    }
    else if (strcmp(bmm150_data, "20"))
    {
        bmm150dr = MAGNETOMETER_BMM150_DATARATE_20HZ;
    }
    else if (strcmp(bmm150_data, "25"))
    {
        bmm150dr = MAGNETOMETER_BMM150_DATARATE_25HZ;
    }
    else if (strcmp(bmm150_data, "8"))
    {
        bmm150dr = MAGNETOMETER_BMM150_DATARATE_8HZ;
    }
    magReturnValue = Magnetometer_setDataRate(xdkMagnetometer_BMM150_Handle, bmm150dr);
    if ((RETCODE_OK != magReturnValue)
            || (MAGNETOMETER_DATARATE_OUT_OF_RANGE == bmm150dr))
    {
        returnVal = BSP_LED_Switch(BSP_XDK_LED_R, BSP_LED_COMMAND_ON);
             if (RETCODE_OK != returnVal)
             {
                 printf("Turning on of RED LED failed");
             }
    }
}

/**
 *  @brief API to Deinitialize the PMD module
 */
extern void bmm_150_deInit(void)
{
    Retcode_T returnValue = RETCODE_FAILURE;
    returnValue = Magnetometer_deInit(xdkMagnetometer_BMM150_Handle);
    if (RETCODE_OK == returnValue)
    {
        printf("Magnetometer Deinit Success\r\n");
    }
    else
    {
        printf("Magnetometer Deinit Failed\r\n");
    }
}

/*************************************************************************** */
