/*
* Licensee agrees that the example code provided to Licensee has been developed and released by Bosch solely as an example to be used as a potential reference for Licensee�s application development. 
* Fitness and suitability of the example code for any use within Licensee�s applications need to be verified by Licensee on its own authority by taking appropriate state of the art actions and measures (e.g. by means of quality assurance measures).
* Licensee shall be responsible for conducting the development of its applications as well as integration of parts of the example code into such applications, taking into account the state of the art of technology and any statutory regulations and provisions applicable for such applications. Compliance with the functional system requirements and testing there of (including validation of information/data security aspects and functional safety) and release shall be solely incumbent upon Licensee. 
* For the avoidance of doubt, Licensee shall be responsible and fully liable for the applications and any distribution of such applications into the market.
* 
* 
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are 
* met:
* 
*     (1) Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer. 
* 
*     (2) Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.  
*     
*     (3)The name of the author may not be used to
*     endorse or promote products derived from this software without
*     specific prior written permission.
* 
*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
*  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
*  DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
*  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
*  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
*  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
*  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
*  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
*  IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
*  POSSIBILITY OF SUCH DAMAGE.
*/
/*----------------------------------------------------------------------------*/
/**
* @ingroup APPS_LIST
*
* @defgroup XDK_APPLICATION_TEMPLATE XDK Application Template
* @{
*
* @brief XDK Application Template
*
* @details Empty XDK Application Template without any functionality. Should be used as a template to start new projects.
*
* @file
**/
/* module includes ********************************************************** */

/* system header files */
#include <stdio.h>
/* additional interface header files */
#include "FreeRTOS.h"
#include "timers.h"
#include <Serval_RestClient.h>
/* own header files */
#include "BOSCH_THINGWORX.h"
#include "BCDS_CmdProcessor.h"
#include "BCDS_Assert.h"
#include "BCDS_WlanConnect.h"
#include "BCDS_NetworkConfig.h"
#include "PAL_initialize_ih.h"
#include "PAL_socketMonitor_ih.h"

/* Interface for all sensors on the XDK */
#include "XdkSensorHandle.h"

/* Sensor Handler for the BME280 Sensor */
extern Environmental_HandlePtr_T xdkEnvironmental_BME280_Handle;
extern Accelerometer_HandlePtr_T xdkAccelerometers_BMI160_Handle;
extern Gyroscope_HandlePtr_T xdkGyroscope_BMI160_Handle;
extern Magnetometer_HandlePtr_T xdkMagnetometer_BMM150_Handle;


/* constant definitions ***************************************************** */

/* local variables ********************************************************** */

/* global variables ********************************************************* */

/* inline functions ********************************************************* */

/* local functions ********************************************************** */
static void onRESTRequestSent(Msg_T *msg_ptr, retcode_t status)
{
	(void) msg_ptr;
	if (status != RC_OK) {
		printf("Failed to send REST request!\r\n");
	}
}

static retcode_t onRESTResponseReceived(RestSession_T *restSession,
Msg_T *msg_ptr, retcode_t status)
{
	(void) restSession;
	if (status == RC_OK && msg_ptr != NULL) {
		Http_StatusCode_T statusCode = HttpMsg_getStatusCode(msg_ptr);
		char const *contentType = HttpMsg_getContentType(msg_ptr);
		char const *content_ptr;
		unsigned int contentLength = 0;
		HttpMsg_getContent(msg_ptr, &content_ptr, &contentLength);
		char content[contentLength+1];
		strncpy(content, content_ptr, contentLength);
		content[contentLength] = 0;
		printf("HTTP RESPONSE: %d [%s]\r\n", statusCode, contentType);
		printf("%s\r\n", content);
	} else {
		printf("Failed to receive REST response!\r\n");
	}
	return(RC_OK);
}

void StreamData(float value, char key[]){
    RestClient_initialize();

    /* Set IP Address and Port */
    Ip_Address_T destAddr;
    //Ip_convertOctetsToAddr(103, 57, 189, 187, &destAddr);
    //The library adds "http://" to the address automatically
    PAL_getIpaddress((uint8_t*) "rpthingworx.com", &destAddr);
    Ip_Port_T port = Ip_convertIntToPort(8080);

    Rest_ContentFormat_T acceptedFormats[1] = { REST_CONTENT_FMT_JSON };
    RestClient_ReqInfo_T putRequest;
    char payload[43];
    sprintf(payload, "{\"%s\": %f}", key, value);
    //printf("{\"Temperature\": %f}", number);
    putRequest.method = REST_PUT;
    putRequest.uriPath_ptr = "/Thingworx/Things/Bosch_LYH/Properties/*";
    putRequest.uriQuery_ptr = "?appKey=03c12ad1-8e7c-4d68-bdd8-49021dc94a94";
    putRequest.acceptBuffer_ptr = acceptedFormats;
    putRequest.numAccept = 1;
    putRequest.payloadLen = 43;
    putRequest.payload_ptr = (uint8_t*) payload;
    putRequest.contentFormat = REST_CONTENT_FMT_JSON;
    putRequest.rangeLength = 0;
    putRequest.host = NULL;

    Msg_T* msg_ptr;
    RestClient_initReqMsg(&destAddr, port, &msg_ptr, REST_CLIENT_PROTOCOL_HTTP);
    RestClient_fillReqMsg(msg_ptr, &putRequest);

    // send the request
    RestClient_request(msg_ptr, &onRESTRequestSent, &onRESTResponseReceived);

}

void initializeEnvironmentalSensor(){
	/* initialize environmental sensor */
	Retcode_T returnValue = RETCODE_FAILURE;
	returnValue = Environmental_init(xdkEnvironmental_BME280_Handle);

	/* initialize accelerometer sensor */
	Retcode_T AccelReturnValue = RETCODE_FAILURE;
	AccelReturnValue = Accelerometer_init(xdkAccelerometers_BMI160_Handle);
	if ( RETCODE_OK != AccelReturnValue) { // do something
		printf("Initialization Error for Accelerometer sensor\n");
	}

	/* initialize gyroscope sensor */
	Retcode_T gyroscopeInitReturnValue = RETCODE_FAILURE;
	gyroscopeInitReturnValue = Gyroscope_init(xdkGyroscope_BMI160_Handle);
	if (RETCODE_OK != gyroscopeInitReturnValue) { // do something
		printf("Initialization Error for Gyroscope sensor\n");
	}

	/* initialize magnetometer sensor */
	Retcode_T magnetometerInitReturnValue = RETCODE_FAILURE;
	magnetometerInitReturnValue = Magnetometer_init(xdkMagnetometer_BMM150_Handle);
	if (RETCODE_OK != magnetometerInitReturnValue) { // do something
		printf("Initialization Error for Magnetometer sensor\n");
	}

	if ( RETCODE_OK != returnValue) {
		printf("Initialization Error\n");
	}

}

void readEnvironmentalSensor(float* pressure, float* temperature, float* humidity){
	/* initialize environmental sensor */
	Retcode_T returnValue = RETCODE_FAILURE;
	returnValue = Environmental_init(xdkEnvironmental_BME280_Handle);
	if ( RETCODE_OK != returnValue) {
	// do something
	}
	/* read and print BME280 environmental sensor data */
	Environmental_Data_T bme280 = { INT32_C(0), UINT32_C(0), UINT32_C(0) };
	returnValue = Environmental_readData(xdkEnvironmental_BME280_Handle, &bme280);
	if ( RETCODE_OK == returnValue) {
		//printf("BME280 Environmental Conversion Data :\n\rp =%ld Pa\n\rt =%ld mDeg\n\rh =%ld %%rh\n\r", (long int) bme280.pressure, (long int) bme280.temperature, (long int) bme280.humidity);
		*pressure = (float) bme280.pressure;
		*temperature = (float) bme280.temperature / 1000;
		*humidity = (float) bme280.humidity;
	}
}

void readAccBMI160(int* AccX, int* AccY, int* AccZ){
	Retcode_T returnValue = RETCODE_FAILURE;
	/* read and print BMI160 accelerometer data */
	Accelerometer_XyzData_T bmiA160 = {INT32_C(0), INT32_C(0), INT32_C(0)};
	memset(&bmiA160, 0, sizeof(Accelerometer_XyzData_T));
	returnValue = Accelerometer_readXyzGValue(xdkAccelerometers_BMI160_Handle,&bmiA160);
	if (RETCODE_OK == returnValue){
		printf("BMI160 Acceleration Data \n\r: %f \n\r %f \n\r %f \n\r", (float) bmiA160.xAxisData, (float) bmiA160.yAxisData, (float) bmiA160.zAxisData);
		*AccX = (long int) bmiA160.xAxisData;
		*AccY = (long int) bmiA160.yAxisData;
		*AccZ = (long int) bmiA160.zAxisData;
	}
}

void readGyroBMI160(int* GyroX, int* GyroY, int* GyroZ){
	Retcode_T returnValue = RETCODE_FAILURE;
	/* read and print BMI160 gyroscope data */
	Gyroscope_XyzData_T bmiG160 = {INT32_C(0), INT32_C(0), INT32_C(0)};
	memset(&bmiG160, 0, sizeof(Gyroscope_XyzData_T));
	returnValue = Gyroscope_readXyzDegreeValue(xdkGyroscope_BMI160_Handle, &bmiG160);
	if (RETCODE_OK == returnValue){
		printf("BMI160 Gyro Data :\n\rx =%ld mDeg\n\ry =%ld mDeg\n\rz =%ld mDeg\n\r", (long int) bmiG160.xAxisData, (long int) bmiG160.yAxisData, (long int) bmiG160.zAxisData);
		*GyroX = (long int) bmiG160.xAxisData;
		*GyroY = (long int) bmiG160.yAxisData;
		*GyroZ = (long int) bmiG160.zAxisData;
	}
}

void readMagBMM150(int* MagX, int* MagY, int* MagZ){
	Retcode_T returnValue = RETCODE_FAILURE;
	/* read and print BMM150 magnetometer data */
	Magnetometer_XyzData_T bmm150 = {INT32_C(0), INT32_C(0), INT32_C(0), INT32_C(0)};
	memset(&bmm150, 0, sizeof(Magnetometer_XyzData_T));

	returnValue = Magnetometer_readXyzTeslaData(xdkMagnetometer_BMM150_Handle, &bmm150);

	if (RETCODE_OK == returnValue) {
		printf("BMM150 Magnetic Data :\n\rx =%ld mT\n\ry =%ld mT\n\rz =%ld mT\n\r", (long int) bmm150.xAxisData, (long int) bmm150.yAxisData, (long int) bmm150.zAxisData);
		*MagX = (long int) bmm150.xAxisData;
		*MagY = (long int) bmm150.yAxisData;
		*MagZ = (long int) bmm150.zAxisData;
	}
}

/* global functions ********************************************************* */

/**
 * Created By : Aldi Faizal, Mehul Gupta
 * Property and Copyright of CAD-IT CONSULTANTS (c) 2018
 *
 */
void appInitSystem(void * CmdProcessorHandle, uint32_t param2)
{
    if (CmdProcessorHandle == NULL)
    {
        printf("Command processor handle is null \n\r");
        assert(false);
    }
    BCDS_UNUSED(param2);

    /* Connect SDK to WiFi Network */

    WlanConnect_SSID_T connectSSID = (WlanConnect_SSID_T) "LYH_AndroidAP";
    WlanConnect_PassPhrase_T connectPassPhrase = (WlanConnect_PassPhrase_T) "fqgg68rq";
    WlanConnect_Init();
    NetworkConfig_SetIpDhcp(0);
    WlanConnect_WPA(connectSSID, connectPassPhrase, NULL);
    PAL_initialize();
    PAL_socketMonitorInit();

    initializeEnvironmentalSensor();
    float sensor_pressure, sensor_temperature, sensor_humidity;
    int Acc_X, Acc_Y, Acc_Z;
    int Gyro_X, Gyro_Y, Gyro_Z;
    int Mag_X, Mag_Y, Mag_Z;

    // Loop for sensor readings
    for(;;){
    	readEnvironmentalSensor(&sensor_pressure, &sensor_temperature, &sensor_humidity);
    	StreamData(sensor_pressure, "Pressure");
    	vTaskDelay((portTickType) 2*1000 / portTICK_RATE_MS);
    	StreamData(sensor_temperature, "Temperature");
		vTaskDelay((portTickType) 2*1000 / portTICK_RATE_MS);
		StreamData(sensor_humidity, "Humidity");
		vTaskDelay((portTickType) 2*1000 / portTICK_RATE_MS);
		vTaskDelay((portTickType) 60*1000 / portTICK_RATE_MS);

		readAccBMI160(&Acc_X, &Acc_Y, &Acc_Z);
		StreamData(Acc_X, "Acc_X");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);
		StreamData(Acc_Y , "Acc_Y");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);
		StreamData(Acc_Z, "Acc_Z");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);

		readGyroBMI160(&Gyro_X, &Gyro_Y, &Gyro_Z);
		StreamData(Gyro_X, "Gyro_X");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);
		StreamData(Gyro_Y , "Gyro_Y");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);
		StreamData(Gyro_Z, "Gyro_Z");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);

		readMagBMM150(&Mag_X, &Mag_Y, &Mag_Z);
		StreamData(Mag_X, "Mag_X");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);
		StreamData(Mag_Y , "Mag_Y");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);
		StreamData(Mag_Z, "Mag_Z");
		//vTaskDelay((portTickType) 1*1000 / portTICK_RATE_MS);
    }
}
/**@} */
/** ************************************************************************* */
